package Util;

public class Info {
    public static final String HOST= "jdbc:mysql://localhost:3306";
    public static final String USER = "root";
    public static final String PASSWORD = "root";
}
